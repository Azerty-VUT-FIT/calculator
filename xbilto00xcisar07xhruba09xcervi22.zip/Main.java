package toTest;

import java.awt.*;
import java.awt.event.*;
import java.applet.Applet;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Main extends Applet implements ActionListener {
   
		JFrame frame = new JFrame("Azerty calculator");
		JPanel panel = new JPanel(new FlowLayout());
	
    JTextField answer = new JTextField("0");

    JButton one = new JButton("1");
    JButton two = new JButton("2");
    JButton three = new JButton("3");
    JButton four = new JButton("4");
    JButton five = new JButton("5");
    JButton six = new JButton("6");
    JButton seven = new JButton("7");
    JButton eight = new JButton("8");
    JButton nine = new JButton("9");
    JButton zero = new JButton("0");
    
    JButton plus = new JButton("+");
    JButton minus = new JButton("-");
    JButton divide = new JButton("/");
    JButton multiply = new JButton("*");
    JButton exponent = new JButton("x^y");
    JButton factorial = new JButton("!");
    JButton modulo = new JButton("%");
    JButton equals = new JButton("=");
    JButton delete = new JButton("C");
    JButton dot = new JButton(".");
    
    String input = "";
    String a = "";
    String b = "";
		int dot_n=0;
    int operace = 0; //plus=1, minus=2, divide=3, multiply=4, modulo=6, factorial=5, exponent=7
    
    public void executeOperation(){
                b=input;
                //System.out.println(operace);
                //System.out.println(a);
                //System.out.println(b);
                switch (operace) {
                    case 1:
                        a=MathLib.getPlus(Double.parseDouble(a),Double.parseDouble(b));
                        break;
                    case 2:
                        a=MathLib.getMinus(Double.parseDouble(a),Double.parseDouble(b));
                        break;
                    case 3:
                        a=MathLib.getDivide(Double.parseDouble(a),Double.parseDouble(b));
                        break;
                    case 4:
                        a=MathLib.getMultiply(Double.parseDouble(a),Double.parseDouble(b));
                        break;
                    case 5:
                        a=MathLib.getFactorial(Integer.parseInt(a));
                        break;
                    case 6:
                        a=MathLib.getModulo(Double.parseDouble(a),Double.parseDouble(b));
                        break;
                    case 7:
                        a=MathLib.getExponent(Double.parseDouble(a),Integer.parseInt(b));
                        break;
                    default:
                        answer.setText(MathLib.mathError);    
                        break;
                }
                operace=0;
                answer.setText(a);
                input="";
    }

    public void init() {
    
		frame.setSize(560,300);
		frame.setVisible(true);
		frame.setResizable(false);
		frame.add(panel);
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
//		panel.setBackground(Color.yellow); 

		panel.add(answer);
		answer.setEditable(false);
		answer.setPreferredSize( new Dimension( 530, 40 ) );
		
		panel.add(seven);
		seven.setPreferredSize( new Dimension( 100, 50 ) );
		seven.addActionListener(this);
		
		panel.add(eight);
		eight.setPreferredSize( new Dimension( 100, 50 ) );
		eight.addActionListener(this);
		
		panel.add(nine);
		nine.setPreferredSize( new Dimension( 100, 50 ) );
		nine.addActionListener(this);
		
		panel.add(plus);
		plus.setPreferredSize( new Dimension( 100, 50 ) );
		plus.addActionListener(this);
		
		panel.add(minus);
		minus.setPreferredSize( new Dimension( 100, 50 ) );
		minus.addActionListener(this);
		
		panel.add(four);
		four.setPreferredSize( new Dimension( 100, 50 ) );
		four.addActionListener(this);
		
		panel.add(five);
		five.setPreferredSize( new Dimension( 100, 50 ) );
		five.addActionListener(this);
		
		panel.add(six);
		six.setPreferredSize( new Dimension( 100, 50 ) );
		six.addActionListener(this);
		
		panel.add(divide);
		divide.setPreferredSize( new Dimension( 100, 50 ) );
		divide.addActionListener(this);
		
		panel.add(multiply);
		multiply.setPreferredSize( new Dimension( 100, 50 ) );
		multiply.addActionListener(this);
		
		
		panel.add(one);
		one.setPreferredSize( new Dimension( 100, 50 ) );
		one.addActionListener(this);
		
		panel.add(two);
		two.setPreferredSize( new Dimension( 100, 50 ) );
		two.addActionListener(this);
		
		panel.add(three);
		three.setPreferredSize( new Dimension( 100, 50 ) );
		three.addActionListener(this);
		
		panel.add(exponent);
		exponent.setPreferredSize( new Dimension( 100, 50 ) );
		exponent.addActionListener(this);
		
		panel.add(factorial);
		factorial.setPreferredSize( new Dimension( 100, 50 ) );
		factorial.addActionListener(this);
		
		panel.add(dot);
		dot.setPreferredSize( new Dimension( 100, 50 ) );
		dot.addActionListener(this);
		
		panel.add(zero);
		zero.setPreferredSize( new Dimension( 100, 50 ) );
		zero.addActionListener(this);
		
		panel.add(modulo);
		modulo.setPreferredSize( new Dimension( 100, 50 ) );
		modulo.addActionListener(this);
		
		panel.add(delete);
		delete.setPreferredSize( new Dimension( 100, 50 ) );
		delete.addActionListener(this);
		
		panel.add(equals);
		equals.setPreferredSize( new Dimension( 100, 50 ) );
		equals.addActionListener(this);

    }
    
    public void actionPerformed(ActionEvent e) {
    	if(e.getSource() == nine){
            if(input.length()<9){	
                answer.setText(input+="9");
            }
        }
        if(e.getSource() == eight){
            if(input.length()<9){
                answer.setText(input+="8");
            }
        }
        if(e.getSource() == seven){
            if(input.length()<9){
                answer.setText(input+="7");
            }
        }
        if(e.getSource() == six){
            if(input.length()<9){
                answer.setText(input+="6");
            }
        }
        if(e.getSource() == five){
            if(input.length()<9){
                answer.setText(input+="5");
            }
        }
        if(e.getSource() == four){
            if(input.length()<9){
                answer.setText(input+="4");
            }
        }
        if(e.getSource() == three){
            if(input.length()<9){
                answer.setText(input+="3");
            }
        }
        if(e.getSource() == two){
            if(input.length()<9){
                answer.setText(input+="2");
            }
        }
        if(e.getSource() == one){
            if(input.length()<9){
                answer.setText(input+="1");
            }
        }
        if(e.getSource() == zero){
            if(input.length()<9){
                answer.setText(input+="0");
            }
        }
   			if(e.getSource() == dot){
            if(input.length()<9 && dot_n<1){
                answer.setText(input+=".");
								dot_n=1;
            }
        }
        if(e.getSource() == delete){
            a="";
            b="";
            input="";
            operace=0;
						dot_n=0;
        	answer.setText("0");
        }
        if (e.getSource()==plus) {
            if (operace!=0){
                executeOperation();
                
                operace=1;
                answer.setText(a);
                input="";
            }
            else{
                operace=1;
                if (a.equals("")) {
                    a=input;
                }
                answer.setText(a);
                input="";
            }
						dot_n=0;
        }
        if (e.getSource()==minus) {
            if (operace!=0){
                executeOperation();
                
                operace=2;
                answer.setText(a);
                input="";
            }
            else{
                operace=2;
                if (a.equals("")) {
                    a=input;
                }
                answer.setText(a);
                input="";
            }
					dot_n=0;
        }
        if (e.getSource()==divide) {
            if (operace!=0){
                executeOperation();
                
                operace=3;
                answer.setText(a);
                input="";
            }
            else{
                operace=3;
                if (a.equals("")) {
                    a=input;
                }
                answer.setText(a);
                input="";
            }
					dot_n=0;
        }
        if (e.getSource()==multiply) {
            if (operace!=0){
                executeOperation();
                
                operace=4;
                answer.setText(a);
                input="";
            }
            else{
                operace=4;
                if (a.equals("")) {
                    a=input;
                }
                answer.setText(a);
                input="";
            }	
					dot_n=0;
        }
        if (e.getSource()==modulo) {
            if (operace!=0){
                executeOperation();
                
                operace=6;
                answer.setText(a);
                input="";
            }
            else{
                operace=6;
                if (a.equals("")) {
                    a=input;
                }
                answer.setText(a);
                input="";
            }
					dot_n=0;
        }
        if (e.getSource()==factorial) {
            operace=5;
            if (a.equals("")) {
                a=input;
            }
            executeOperation();
            answer.setText(a);
            input="";
						dot_n=0;
            
        }
        if (e.getSource()==exponent) {
            if (operace!=0){
                executeOperation();
                
                operace=7;
                answer.setText(a);
                input="";
            }
            else{
                operace=7;
                if (a.equals("")) {
                    a=input;
                }
                answer.setText(a);
                input="";
            }
					dot_n=0;
        }

        if (e.getSource() == equals){
            //System.out.println(a);
            //System.out.println(b);
            //System.out.println(input);
            if (a.equals("")){
                if(input.equals("")) {
                        a="0";
                    input=a;
                }
                    
                
                a=input;
                operace=0;
                answer.setText(a);
                input="";
            }
            else{
                executeOperation();
            }
            input="";
						dot_n=0;
						a="";
        }
    }
    
    public static void main(String args[]) {

            Main applet = new Main();     
            applet.init();
    
        
    }


}
