?package(calculator):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="calculator" command="/usr/bin/calculator"
